<?php   

define ( '_MAILHOST', 'mail.frontnetwork.com' );
define ( '_SMTPUSER', 'test@frontnetwork.com' );
define ( '_SMTPPW', 'front123' );

function smtpmail($title,$message){
header("Content-Type:text/html;chareset:utf-8");
include('class.phpmailer.php');
$mail=new phpmailer();
$address="";
$mail->IsSMTP();
$mail->Host=_MAILHOST;//企业邮箱域名
$mail->Port        = 25;
$mail->SMTPAuth=true;
$mail->Username=_SMTPUSER;//企业邮箱用户名
$mail->Password=_SMTPPW;//企业邮箱密码
$mail->From=_SMTPUSER;//邮件发送者的地址
$mail->FromName='test';//
$mail->Hostname=_MAILHOST;
$mail->Encoding = 'base64';
$mail->CharSet = 'utf-8';
$mail->AddAddress('dongqian_0201@sina.com');//收件人地址
$mail->IsHTML(true);//是否使用HTML格式
$mail->Subject="$title";
$mail->Body="$message";
if(!$mail->Send()) { 
	echo 1;
	 // return false;
    } else { 
		echo 2;
	 // return true;
    }  
}
 smtpmail('123.196.115.70 user login','123.196.115.70 user login');
?>
